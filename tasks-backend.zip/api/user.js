const bcrypt = require('bcrypt-nodejs') // para criptografia

module.exports = app => {
    const obterHash = (password, callback) => { // aplicando a criptografia na senhar do user
        bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(password, salt, null, (err, hash) => callback(hash))
        })
    }

    const save = (req, res) => { // inserindo os dados do user
        obterHash(req.body.password, hash => {
            const password = hash

            app.db('users')
                .insert({ name: req.body.name, email: req.body.email, password })
                .then(_ => res.status(204).send())
                .catch(err => res.status(400).json(err))
        })
    }

    return { save } // exportando os dados do user 
}